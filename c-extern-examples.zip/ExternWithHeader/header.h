#include "source1.c"

extern int callCount;

void someFunction();
