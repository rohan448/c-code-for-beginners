
int callCount = 0;

void someFunction()
{
    //do something

    callCount++;
}
